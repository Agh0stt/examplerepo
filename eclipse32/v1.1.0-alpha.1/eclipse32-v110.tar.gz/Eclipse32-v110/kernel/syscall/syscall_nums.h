#pragma once

// Process (0-9)
#define SYS_EXIT        0
#define SYS_FORK        1
#define SYS_EXEC        2
#define SYS_GETPID      3
#define SYS_GETPPID     4
#define SYS_WAIT        5
#define SYS_SLEEP       6
#define SYS_YIELD       7
#define SYS_KILL        8
#define SYS_SIGNAL      9

// File I/O (10-24)
#define SYS_OPEN        10
#define SYS_CLOSE       11
#define SYS_READ        12
#define SYS_WRITE       13
#define SYS_SEEK        14
#define SYS_STAT        15
#define SYS_FSTAT       16
#define SYS_DUP         17
#define SYS_DUP2        18
#define SYS_PIPE        19
#define SYS_FCNTL       20
#define SYS_IOCTL       21
#define SYS_TRUNCATE    22
#define SYS_FTRUNCATE   23
#define SYS_SYNC        24

// Filesystem (25-34)
#define SYS_MKDIR       25
#define SYS_RMDIR       26
#define SYS_UNLINK      27
#define SYS_RENAME      28
#define SYS_LINK        29
#define SYS_SYMLINK     30
#define SYS_READLINK    31
#define SYS_CHDIR       32
#define SYS_GETCWD      33
#define SYS_READDIR     34

// Memory (35-41)
#define SYS_MMAP        35
#define SYS_MUNMAP      36
#define SYS_MPROTECT    37
#define SYS_BRK         38
#define SYS_SBRK        39
#define SYS_MLOCK       40
#define SYS_MUNLOCK     41

// Time (42-46)
#define SYS_TIME            42
#define SYS_GETTIMEOFDAY    43
#define SYS_SETTIMEOFDAY    44
#define SYS_CLOCK_GETTIME   45
#define SYS_UPTIME          46

// Terminal/IO (47-53)
#define SYS_IOCTL_TTY   47
#define SYS_ISATTY      48
#define SYS_GETCHAR     49
#define SYS_PUTCHAR     50
#define SYS_GETS        51
#define SYS_PUTS        52
#define SYS_POLL        53

// System (54-61)
#define SYS_UNAME       54
#define SYS_REBOOT      55
#define SYS_HALT        56
#define SYS_POWEROFF    57
#define SYS_SYSINFO     58
#define SYS_GETENV      59
#define SYS_SETENV      60
#define SYS_UNSETENV    61

// Device (62-66)
#define SYS_MOUNT       62
#define SYS_UMOUNT      63
#define SYS_OPENDEV     64
#define SYS_READDEV     65
#define SYS_WRITEDEV    66

// Network (67-69)
#define SYS_SOCKET      67
#define SYS_CONNECT     68
#define SYS_SEND        69

#define SYSCALL_MAX     70
