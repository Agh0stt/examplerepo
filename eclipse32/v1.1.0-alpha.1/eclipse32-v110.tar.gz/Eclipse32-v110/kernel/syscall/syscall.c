// =============================================================================
// Eclipse32 - Syscall Dispatcher & Handlers
// int 0x80: eax=num, ebx=a1, ecx=a2, edx=a3, esi=a4, edi=a5
// Returns: eax (negative = error code)
// =============================================================================
#include "syscall.h"
#include "../kernel.h"
#include "../fs/fat32/fat32.h"
#include "../drivers/vga/vga.h"
#include "../drivers/keyboard/keyboard.h"
#include "../arch/x86/pit.h"
#include "../mm/heap.h"
#include "../mm/pmm.h"
#include "../initramfs/initramfs.h"

// ---- Forward declarations for helpers ---------------------------------------
static int32_t sys_exit(uint32_t code);
static int32_t sys_write(uint32_t fd, uint32_t buf, uint32_t count);
static int32_t sys_read(uint32_t fd, uint32_t buf, uint32_t count);

// ---- Process heap break (simple bump allocator for userspace) ---------------
static uint32_t _user_brk = 0x40000000;   // userspace heap starts at 1GB mark

// =============================================================================
// Process syscalls (0-9)
// =============================================================================
static int32_t sys_exit(uint32_t code) {
    // For now: just halt. Will be replaced when process table exists.
    (void)code;
    // Return to the shell by longjmp-style — not yet implemented.
    // For now print and loop; process model comes in v2.
    vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
    vga_puts("\n[syscall] process exited\n");
    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    return 0;
}

static int32_t sys_fork(void) {
    return -(ENOSYS);   // Requires scheduler — v2.0
}

static int32_t sys_exec(uint32_t path, uint32_t argv) {
    (void)path; (void)argv;
    return -(ENOSYS);   // Requires ELF/bin32 loader — v1.1.0
}

static int32_t sys_getpid(void) {
    return 1;           // Single process for now
}

static int32_t sys_getppid(void) {
    return 0;
}

static int32_t sys_wait(uint32_t pid, uint32_t status_ptr) {
    (void)pid; (void)status_ptr;
    return -(ENOSYS);
}

static int32_t sys_sleep(uint32_t ms) {
    pit_sleep_ms(ms);
    return 0;
}

static int32_t sys_yield(void) {
    // No scheduler yet — just return
    return 0;
}

static int32_t sys_kill(uint32_t pid, uint32_t sig) {
    (void)pid; (void)sig;
    return -(ENOSYS);
}

static int32_t sys_signal(uint32_t signum, uint32_t handler) {
    (void)signum; (void)handler;
    return -(ENOSYS);
}

// =============================================================================
// File I/O syscalls (10-24)
// =============================================================================
static int32_t sys_open(uint32_t path, uint32_t flags, uint32_t mode) {
    (void)mode;
    if (!path) return -(EINVAL);
    return fat32_open((const char *)path, (int)flags);
}

static int32_t sys_close(uint32_t fd) {
    return fat32_close((int)fd);
}

static int32_t sys_read(uint32_t fd, uint32_t buf, uint32_t count) {
    if (!buf) return -(EINVAL);

    // fd 0 = stdin: read from keyboard
    if (fd == 0) {
        char *out = (char *)buf;
        uint32_t i = 0;
        while (i < count) {
            key_event_t ev = keyboard_wait_event();
            if (ev.released) continue;
            if (ev.keycode != KEY_ASCII) continue;
            char c = ev.ascii;
            out[i++] = c;
            vga_putchar(c);
            if (c == '\n' || c == '\r') break;
        }
        return (int32_t)i;
    }

    return fat32_read((int)fd, (void *)buf, count);
}

static int32_t sys_write(uint32_t fd, uint32_t buf, uint32_t count) {
    if (!buf) return -(EINVAL);
    const char *data = (const char *)buf;

    // fd 1 = stdout, fd 2 = stderr: write to VGA
    if (fd == 1 || fd == 2) {
        for (uint32_t i = 0; i < count; i++)
            vga_putchar(data[i]);
        return (int32_t)count;
    }

    return fat32_write((int)fd, data, count);
}

static int32_t sys_seek(uint32_t fd, uint32_t offset, uint32_t whence) {
    return fat32_seek((int)fd, (int32_t)offset, (int)whence);
}

static int32_t sys_stat(uint32_t path, uint32_t buf) {
    if (!path || !buf) return -(EINVAL);
    fat32_stat_t *st = (fat32_stat_t *)buf;
    return fat32_stat((const char *)path, st);
}

static int32_t sys_fstat(uint32_t fd, uint32_t buf) {
    (void)fd; (void)buf;
    return -(ENOSYS);   // Need per-fd metadata — future work
}

static int32_t sys_dup(uint32_t fd) {
    (void)fd;
    return -(ENOSYS);
}

static int32_t sys_dup2(uint32_t oldfd, uint32_t newfd) {
    (void)oldfd; (void)newfd;
    return -(ENOSYS);
}

static int32_t sys_pipe(uint32_t fds) {
    (void)fds;
    return -(ENOSYS);
}

static int32_t sys_fcntl(uint32_t fd, uint32_t cmd, uint32_t arg) {
    (void)fd; (void)cmd; (void)arg;
    return -(ENOSYS);
}

static int32_t sys_ioctl(uint32_t fd, uint32_t req, uint32_t arg) {
    (void)fd; (void)req; (void)arg;
    return -(ENOSYS);
}

static int32_t sys_truncate(uint32_t path, uint32_t length) {
    (void)path; (void)length;
    return -(ENOSYS);
}

static int32_t sys_ftruncate(uint32_t fd, uint32_t length) {
    (void)fd; (void)length;
    return -(ENOSYS);
}

static int32_t sys_sync(void) {
    return 0;   // FAT32 writes are synchronous already
}

// =============================================================================
// Filesystem syscalls (25-34)
// =============================================================================
static int32_t sys_mkdir(uint32_t path, uint32_t mode) {
    (void)mode;
    if (!path) return -(EINVAL);
    return fat32_mkdir((const char *)path);
}

static int32_t sys_rmdir(uint32_t path) {
    if (!path) return -(EINVAL);
    return fat32_delete((const char *)path);
}

static int32_t sys_unlink(uint32_t path) {
    if (!path) return -(EINVAL);
    return fat32_delete((const char *)path);
}

static int32_t sys_rename(uint32_t oldpath, uint32_t newpath) {
    if (!oldpath || !newpath) return -(EINVAL);
    return fat32_rename((const char *)oldpath, (const char *)newpath);
}

static int32_t sys_link(uint32_t old, uint32_t new) {
    (void)old; (void)new;
    return -(ENOSYS);   // FAT32 has no hard links
}

static int32_t sys_symlink(uint32_t target, uint32_t linkpath) {
    (void)target; (void)linkpath;
    return -(ENOSYS);   // FAT32 has no symlinks
}

static int32_t sys_readlink(uint32_t path, uint32_t buf, uint32_t bufsiz) {
    (void)path; (void)buf; (void)bufsiz;
    return -(ENOSYS);
}

static int32_t sys_chdir(uint32_t path) {
    // Shell owns cwd — expose via env for now
    if (!path) return -(EINVAL);
    fat32_stat_t st;
    if (fat32_stat((const char *)path, &st) != 0) return -(ENOENT);
    if (!st.is_dir) return -(ENOENT);
    env_set("PWD", (const char *)path);
    return 0;
}

static int32_t sys_getcwd(uint32_t buf, uint32_t size) {
    if (!buf || !size) return -(EINVAL);
    const char *cwd = env_get("PWD");
    if (!cwd) cwd = "/";
    char *out = (char *)buf;
    uint32_t i = 0;
    while (cwd[i] && i < size - 1) { out[i] = cwd[i]; i++; }
    out[i] = 0;
    return (int32_t)i;
}

static int32_t sys_readdir(uint32_t fd, uint32_t entry_ptr) {
    (void)fd; (void)entry_ptr;
    return -(ENOSYS);   // Needs per-fd directory state — future work
}

// =============================================================================
// Memory syscalls (35-41)
// =============================================================================
static int32_t sys_mmap(uint32_t addr, uint32_t length, uint32_t prot,
                        uint32_t flags, uint32_t fd) {
    (void)addr; (void)prot; (void)flags; (void)fd;
    // Simple: just bump-allocate from heap
    void *p = kmalloc(length);
    if (!p) return -(ENOMEM);
    return (int32_t)p;
}

static int32_t sys_munmap(uint32_t addr, uint32_t length) {
    (void)length;
    if (!addr) return -(EINVAL);
    kfree((void *)addr);
    return 0;
}

static int32_t sys_mprotect(uint32_t addr, uint32_t length, uint32_t prot) {
    (void)addr; (void)length; (void)prot;
    return 0;   // No-op until proper VMM per-process
}

static int32_t sys_brk(uint32_t addr) {
    if (addr == 0) return (int32_t)_user_brk;
    _user_brk = addr;
    return (int32_t)_user_brk;
}

static int32_t sys_sbrk(uint32_t increment) {
    uint32_t old = _user_brk;
    _user_brk += increment;
    return (int32_t)old;
}

static int32_t sys_mlock(uint32_t addr, uint32_t length) {
    (void)addr; (void)length;
    return 0;
}

static int32_t sys_munlock(uint32_t addr, uint32_t length) {
    (void)addr; (void)length;
    return 0;
}

// =============================================================================
// Time syscalls (42-46)
// =============================================================================
static int32_t sys_time(void) {
    // Return uptime in seconds as a rough time_t
    return (int32_t)(pit_ms() / 1000);
}

static int32_t sys_gettimeofday(uint32_t tv, uint32_t tz) {
    (void)tz;
    if (!tv) return -(EINVAL);
    uint32_t *t = (uint32_t *)tv;
    t[0] = pit_ms() / 1000;    // tv_sec
    t[1] = (pit_ms() % 1000) * 1000; // tv_usec
    return 0;
}

static int32_t sys_settimeofday(uint32_t tv, uint32_t tz) {
    (void)tv; (void)tz;
    return 0;
}

static int32_t sys_clock_gettime(uint32_t clkid, uint32_t tp) {
    (void)clkid;
    if (!tp) return -(EINVAL);
    uint32_t *t = (uint32_t *)tp;
    uint32_t ms = pit_ms();
    t[0] = ms / 1000;               // tv_sec
    t[1] = (ms % 1000) * 1000000;   // tv_nsec
    return 0;
}

static int32_t sys_uptime(void) {
    return (int32_t)pit_ms();
}

// =============================================================================
// Terminal/IO syscalls (47-53)
// =============================================================================
static int32_t sys_ioctl_tty(uint32_t fd, uint32_t cmd, uint32_t arg) {
    (void)fd; (void)cmd; (void)arg;
    return 0;
}

static int32_t sys_isatty(uint32_t fd) {
    return (fd == 0 || fd == 1 || fd == 2) ? 1 : 0;
}

static int32_t sys_getchar(void) {
    while (1) {
        key_event_t ev = keyboard_wait_event();
        if (!ev.released && ev.keycode == KEY_ASCII)
            return (int32_t)(unsigned char)ev.ascii;
    }
}

static int32_t sys_putchar(uint32_t c) {
    vga_putchar((char)c);
    return (int32_t)c;
}

static int32_t sys_gets(uint32_t buf, uint32_t size) {
    if (!buf || !size) return -(EINVAL);
    char *out = (char *)buf;
    uint32_t i = 0;
    while (i < size - 1) {
        key_event_t ev = keyboard_wait_event();
        if (ev.released) continue;
        if (ev.keycode != KEY_ASCII) continue;
        char c = ev.ascii;
        if (c == '\n' || c == '\r') { vga_putchar('\n'); break; }
        if (c == '\b' || c == 127) {
            if (i > 0) { i--; vga_putchar('\b'); vga_putchar(' '); vga_putchar('\b'); }
            continue;
        }
        out[i++] = c;
        vga_putchar(c);
    }
    out[i] = 0;
    return (int32_t)i;
}

static int32_t sys_puts(uint32_t str) {
    if (!str) return -(EINVAL);
    const char *s = (const char *)str;
    while (*s) vga_putchar(*s++);
    vga_putchar('\n');
    return 0;
}

static int32_t sys_poll(uint32_t fds, uint32_t nfds, uint32_t timeout) {
    (void)fds; (void)nfds; (void)timeout;
    return -(ENOSYS);
}

// =============================================================================
// System syscalls (54-61)
// =============================================================================

// utsname layout (simplified, 65-byte fields)
typedef struct {
    char sysname[65];
    char nodename[65];
    char release[65];
    char version[65];
    char machine[65];
} utsname_t;

static void _strcpy_s(char *dst, const char *src, int max) {
    int i = 0;
    while (src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = 0;
}

static int32_t sys_uname(uint32_t buf) {
    if (!buf) return -(EINVAL);
    utsname_t *u = (utsname_t *)buf;
    _strcpy_s(u->sysname,   "Eclipse32",       65);
    _strcpy_s(u->nodename,  "eclipse",          65);
    _strcpy_s(u->release,   "1.1.0",            65);
    _strcpy_s(u->version,   "#1 Eclipse32 SMP", 65);
    _strcpy_s(u->machine,   "i686",             65);
    return 0;
}

static int32_t sys_reboot(void) {
    uint8_t g = 0x02;
    while (g & 0x02) g = inb(0x64);
    outb(0x64, 0xFE);
    asm volatile("cli; hlt");
    return 0;
}

static int32_t sys_halt(void) {
    asm volatile("cli; hlt");
    return 0;
}

static int32_t sys_poweroff(void) {
    // ACPI S5 — try both QEMU and older ports
    outw(0x604, 0x2000);    // QEMU
    outw(0x4004, 0x3400);   // Bochs/older
    asm volatile("cli; hlt");
    return 0;
}

// sysinfo layout (simplified)
typedef struct {
    uint32_t uptime;
    uint32_t totalram;
    uint32_t freeram;
    uint32_t procs;
} sysinfo_t;

static int32_t sys_sysinfo(uint32_t buf) {
    if (!buf) return -(EINVAL);
    sysinfo_t *si = (sysinfo_t *)buf;
    si->uptime   = pit_ms() / 1000;
    si->totalram = 32 * 1024 * 1024;
    si->freeram  = pmm_free_count() * 4096;
    si->procs    = 1;
    return 0;
}

static int32_t sys_getenv(uint32_t name, uint32_t buf) {
    if (!name || !buf) return -(EINVAL);
    const char *val = env_get((const char *)name);
    if (!val) return -(ENOENT);
    char *out = (char *)buf;
    int i = 0;
    while (val[i]) { out[i] = val[i]; i++; }
    out[i] = 0;
    return 0;
}

static int32_t sys_setenv(uint32_t name, uint32_t value, uint32_t overwrite) {
    if (!name || !value) return -(EINVAL);
    (void)overwrite;
    env_set((const char *)name, (const char *)value);
    return 0;
}

static int32_t sys_unsetenv(uint32_t name) {
    if (!name) return -(EINVAL);
    env_unset((const char *)name);
    return 0;
}

// =============================================================================
// Device syscalls (62-66)
// =============================================================================
static int32_t sys_mount(uint32_t source, uint32_t target, uint32_t fstype) {
    (void)source; (void)target; (void)fstype;
    return -(ENOSYS);
}

static int32_t sys_umount(uint32_t target) {
    (void)target;
    return -(ENOSYS);
}

static int32_t sys_opendev(uint32_t name, uint32_t flags) {
    (void)name; (void)flags;
    return -(ENOSYS);   // Device layer comes in v1.1.1
}

static int32_t sys_readdev(uint32_t devfd, uint32_t buf,
                           uint32_t count, uint32_t offset) {
    (void)devfd; (void)buf; (void)count; (void)offset;
    return -(ENOSYS);
}

static int32_t sys_writedev(uint32_t devfd, uint32_t buf,
                            uint32_t count, uint32_t offset) {
    (void)devfd; (void)buf; (void)count; (void)offset;
    return -(ENOSYS);
}

// =============================================================================
// Network syscalls (67-69)
// =============================================================================
static int32_t sys_socket(uint32_t domain, uint32_t type, uint32_t protocol) {
    (void)domain; (void)type; (void)protocol;
    return -(ENOSYS);   // Network stack comes in v1.1.1
}

static int32_t sys_connect(uint32_t sockfd, uint32_t addr, uint32_t addrlen) {
    (void)sockfd; (void)addr; (void)addrlen;
    return -(ENOSYS);
}

static int32_t sys_send(uint32_t sockfd, uint32_t buf,
                        uint32_t len, uint32_t flags) {
    (void)sockfd; (void)buf; (void)len; (void)flags;
    return -(ENOSYS);
}

// =============================================================================
// Dispatcher
// =============================================================================
int32_t syscall_dispatch(uint32_t num,
                         uint32_t a1, uint32_t a2, uint32_t a3,
                         uint32_t a4, uint32_t a5) {
    switch (num) {
    // Process
    case SYS_EXIT:      return sys_exit(a1);
    case SYS_FORK:      return sys_fork();
    case SYS_EXEC:      return sys_exec(a1, a2);
    case SYS_GETPID:    return sys_getpid();
    case SYS_GETPPID:   return sys_getppid();
    case SYS_WAIT:      return sys_wait(a1, a2);
    case SYS_SLEEP:     return sys_sleep(a1);
    case SYS_YIELD:     return sys_yield();
    case SYS_KILL:      return sys_kill(a1, a2);
    case SYS_SIGNAL:    return sys_signal(a1, a2);
    // File I/O
    case SYS_OPEN:      return sys_open(a1, a2, a3);
    case SYS_CLOSE:     return sys_close(a1);
    case SYS_READ:      return sys_read(a1, a2, a3);
    case SYS_WRITE:     return sys_write(a1, a2, a3);
    case SYS_SEEK:      return sys_seek(a1, a2, a3);
    case SYS_STAT:      return sys_stat(a1, a2);
    case SYS_FSTAT:     return sys_fstat(a1, a2);
    case SYS_DUP:       return sys_dup(a1);
    case SYS_DUP2:      return sys_dup2(a1, a2);
    case SYS_PIPE:      return sys_pipe(a1);
    case SYS_FCNTL:     return sys_fcntl(a1, a2, a3);
    case SYS_IOCTL:     return sys_ioctl(a1, a2, a3);
    case SYS_TRUNCATE:  return sys_truncate(a1, a2);
    case SYS_FTRUNCATE: return sys_ftruncate(a1, a2);
    case SYS_SYNC:      return sys_sync();
    // Filesystem
    case SYS_MKDIR:     return sys_mkdir(a1, a2);
    case SYS_RMDIR:     return sys_rmdir(a1);
    case SYS_UNLINK:    return sys_unlink(a1);
    case SYS_RENAME:    return sys_rename(a1, a2);
    case SYS_LINK:      return sys_link(a1, a2);
    case SYS_SYMLINK:   return sys_symlink(a1, a2);
    case SYS_READLINK:  return sys_readlink(a1, a2, a3);
    case SYS_CHDIR:     return sys_chdir(a1);
    case SYS_GETCWD:    return sys_getcwd(a1, a2);
    case SYS_READDIR:   return sys_readdir(a1, a2);
    // Memory
    case SYS_MMAP:      return sys_mmap(a1, a2, a3, a4, a5);
    case SYS_MUNMAP:    return sys_munmap(a1, a2);
    case SYS_MPROTECT:  return sys_mprotect(a1, a2, a3);
    case SYS_BRK:       return sys_brk(a1);
    case SYS_SBRK:      return sys_sbrk(a1);
    case SYS_MLOCK:     return sys_mlock(a1, a2);
    case SYS_MUNLOCK:   return sys_munlock(a1, a2);
    // Time
    case SYS_TIME:          return sys_time();
    case SYS_GETTIMEOFDAY:  return sys_gettimeofday(a1, a2);
    case SYS_SETTIMEOFDAY:  return sys_settimeofday(a1, a2);
    case SYS_CLOCK_GETTIME: return sys_clock_gettime(a1, a2);
    case SYS_UPTIME:        return sys_uptime();
    // Terminal
    case SYS_IOCTL_TTY: return sys_ioctl_tty(a1, a2, a3);
    case SYS_ISATTY:    return sys_isatty(a1);
    case SYS_GETCHAR:   return sys_getchar();
    case SYS_PUTCHAR:   return sys_putchar(a1);
    case SYS_GETS:      return sys_gets(a1, a2);
    case SYS_PUTS:      return sys_puts(a1);
    case SYS_POLL:      return sys_poll(a1, a2, a3);
    // System
    case SYS_UNAME:     return sys_uname(a1);
    case SYS_REBOOT:    return sys_reboot();
    case SYS_HALT:      return sys_halt();
    case SYS_POWEROFF:  return sys_poweroff();
    case SYS_SYSINFO:   return sys_sysinfo(a1);
    case SYS_GETENV:    return sys_getenv(a1, a2);
    case SYS_SETENV:    return sys_setenv(a1, a2, a3);
    case SYS_UNSETENV:  return sys_unsetenv(a1);
    // Device
    case SYS_MOUNT:     return sys_mount(a1, a2, a3);
    case SYS_UMOUNT:    return sys_umount(a1);
    case SYS_OPENDEV:   return sys_opendev(a1, a2);
    case SYS_READDEV:   return sys_readdev(a1, a2, a3, a4);
    case SYS_WRITEDEV:  return sys_writedev(a1, a2, a3, a4);
    // Network
    case SYS_SOCKET:    return sys_socket(a1, a2, a3);
    case SYS_CONNECT:   return sys_connect(a1, a2, a3);
    case SYS_SEND:      return sys_send(a1, a2, a3, a4);

    default:            return -(ENOSYS);
    }
}

void syscall_init(void) {
    // Nothing to do yet — IDT gate 0x80 is already set in idt_init()
    vga_puts("[INIT] Syscall layer ready (int 0x80, 70 syscalls)\n");
}
