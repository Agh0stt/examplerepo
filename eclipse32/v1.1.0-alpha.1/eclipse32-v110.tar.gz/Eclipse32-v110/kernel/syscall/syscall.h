#pragma once
#include "../kernel.h"
#include "syscall_nums.h"

// Error codes returned as negative values
#define EPERM    1
#define ENOENT   2
#define ESRCH    3
#define EINTR    4
#define EIO      5
#define EBADF    9
#define ENOMEM  12
#define EACCES  13
#define EINVAL  22
#define ENOSYS  38

// Main dispatcher — called from interrupt_dispatch when int_num == 0x80
int32_t syscall_dispatch(uint32_t num,
                         uint32_t a1, uint32_t a2, uint32_t a3,
                         uint32_t a4, uint32_t a5);

// Initialise syscall subsystem
void syscall_init(void);
